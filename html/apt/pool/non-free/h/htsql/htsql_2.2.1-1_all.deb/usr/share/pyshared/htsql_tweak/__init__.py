#
# Copyright (c) 2006-2011, Prometheus Research, LLC
# See `LICENSE` for license information, `AUTHORS` for the list of authors.
#


from htsql.addon import Addon

class TweakAddon(Addon):

    name = 'tweak'
    prerequisites = []
    hint = """contain various tweaks for HTSQL"""


